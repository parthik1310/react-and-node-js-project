const ProjectData = [
    {
        id: 1,
        type: "Mobile Application Design",
        title: "Example One UI/UX Design",
        description:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
    },
    {
        id: 2,
        type: "Website Design",
        title: "Example TWO UI/UX Design",
        description:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
    },
    {
        id: 3,
        type: "Mobile Application Design",
        title: "Example One UI/UX Design",
        description:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
    },
    {
        id: 4,
        type: "Website Design",
        title: "Example TWO UI/UX Design",
        description:
            "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
    },
];

export default ProjectData;
