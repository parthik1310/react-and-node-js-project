const ServiceData = [
    {
        title: "UI/UX Design From Scratch",
        description: "Develop your all product from scratch",
        link: "/services/services-details",
    },
    {
        title: "Graphics Design",
        description: "Business identity Design, Banner Design, Borcher Design etc...",
        link: "/services/services-details",
    },
    {
        title: "Mobile Application Design",
        description: "I’ll design your application from scratch",
        link: "/services/services-details",
    },
    {
        title: "Mobile Application Redesign",
        description: "Give your old mobile application new look to gain customer reach",
        link: "/services/services-details",
    },
    {
        title: "Website Design",
        description: "I’ll design your website from scratch",
        link: "/services/services-details",
    },
    {
        title: "Website Redesign",
        description: "Give your old website new look to gain customer Reach",
        link: "/services/services-details",
    },
    {
        title: "Social Media Design",
        description: "Posts, Stories, Profile images, Graphics, and other Visuals etc...",
        link: "/services/services-details",
    },
    {
        title: "Consultation",
        description: "All kind of design related consultations",
        link: "/services/services-details",
    },
];

export default ServiceData;
