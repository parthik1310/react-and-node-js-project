import ClientLogo1 from "@/images/client_logos/client_logo1.png";
import ClientLogo2 from "@/images/client_logos/client_logo2.png";
import ClientLogo3 from "@/images/client_logos/client_logo3.png";
import ClientLogo4 from "@/images/client_logos/client_logo4.png";
import ClientLogo5 from "@/images/client_logos/client_logo5.png";
import ClientLogo6 from "@/images/client_logos/client_logo6.png";
import ClientLogo7 from "@/images/client_logos/client_logo7.png";
import ClientLogo8 from "@/images/client_logos/client_logo8.png";
import ClientLogo9 from "@/images/client_logos/client_logo9.png";
import ClientLogo10 from "@/images/client_logos/client_logo10.png";
import ClientLogo11 from "@/images/client_logos/client_logo11.png";
import ClientLogo12 from "@/images/client_logos/client_logo12.png";
import ClientLogo13 from "@/images/client_logos/client_logo13.png";
import ClientLogo14 from "@/images/client_logos/client_logo14.png";
import ClientLogo15 from "@/images/client_logos/client_logo15.png";
import ClientLogo16 from "@/images/client_logos/client_logo16.png";
import ClientLogo17 from "@/images/client_logos/client_logo17.png";
import ClientLogo18 from "@/images/client_logos/client_logo18.png";
import ClientLogo19 from "@/images/client_logos/client_logo19.png";
import ClientLogo20 from "@/images/client_logos/client_logo20.png";
import ClientLogo21 from "@/images/client_logos/client_logo21.png";
import ClientLogo22 from "@/images/client_logos/client_logo22.png";
import ClientLogo23 from "@/images/client_logos/client_logo23.png";

const ClientLogoData = [
    {
        image: ClientLogo1,
    },
    {
        image: ClientLogo2,
    },
    {
        image: ClientLogo3,
    },
    {
        image: ClientLogo4,
    },
    {
        image: ClientLogo5,
    },
    {
        image: ClientLogo6,
    },
    {
        image: ClientLogo7,
    },
    {
        image: ClientLogo8,
    },
    {
        image: ClientLogo9,
    },
    {
        image: ClientLogo10,
    },
    {
        image: ClientLogo11,
    },
    {
        image: ClientLogo12,
    },
    {
        image: ClientLogo13,
    },
    {
        image: ClientLogo14,
    },
    {
        image: ClientLogo15,
    },
    {
        image: ClientLogo16,
    },
    {
        image: ClientLogo17,
    },
    {
        image: ClientLogo18,
    },
    {
        image: ClientLogo19,
    },
    {
        image: ClientLogo20,
    },
    {
        image: ClientLogo21,
    },
    {
        image: ClientLogo22,
    },
    {
        image: ClientLogo23,
    },
];

export default ClientLogoData;
